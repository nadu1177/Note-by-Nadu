export default function Home() {
  return (
    <div style={{ fontFamily: 'Poppins, sans-serif', textAlign: 'center', marginTop: '50px' }}>
      <h1>📒 Welcome to Note-by-Nadu</h1>
      <p>Personal & Colorful Note App Powered by Firebase + AI</p>
    </div>
  );
}
